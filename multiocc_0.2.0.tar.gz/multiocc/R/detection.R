#' \describe{site by season by survey, for six species.
#' Also contains the standardized covariate duration.}
#' @name detection
#' @usage data(detection)
#' @title Detection
"detection"

