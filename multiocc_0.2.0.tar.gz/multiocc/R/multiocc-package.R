#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom coda as.mcmc
#' @importFrom coda varnames
#' @importFrom interp interp
#' @importFrom stats aggregate
#' @importFrom stats dist
#' @importFrom stats pnorm
#' @importFrom stats runif
#' @importFrom stats var
#' @importFrom utils setTxtProgressBar
#' @importFrom utils txtProgressBar
## usethis namespace: end
NULL
