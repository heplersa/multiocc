#' \describe{site by season with covariate forest (standardized percentage forest cover)
#'  and elevation (standardized).}
#' @name occupancy
#' @usage data(occupancy)
#' @title Occupancy
"occupancy"
