

#' \describe{site by x coordinate by y coordinate}
#' @name coords
#' @usage data(coords)
#' @title Coords
"coords"
